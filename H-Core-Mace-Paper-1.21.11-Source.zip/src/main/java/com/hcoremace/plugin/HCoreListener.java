package com.hcoremace.plugin;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;

public final class HCoreListener implements Listener {
    private final HCoreMacePlugin plugin;

    public HCoreListener(HCoreMacePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getData(player);

        if (!player.hasPlayedBefore()) {
            plugin.firstJoin(player);
        } else if (data.getPath() == Path.NONE) {
            plugin.gui().openPathMenu(player);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        PlayerData data = plugin.getData(event.getPlayer());
        plugin.getDataManager().save(event.getPlayer(), data);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        plugin.gui().handleClick(event);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Entity killerEntity = victim.getKiller();

        if (plugin.getConfig().getBoolean("drop.only-player-kills", true)
                && !(killerEntity instanceof Player)) {
            return;
        }

        if (killerEntity instanceof Player && plugin.items().isMace(((Player) killerEntity).getInventory().getItemInMainHand())) {
            ItemStack core = plugin.items().createCore();
            int amount = plugin.getConfig().getInt("drop.amount", 1);
            core.setAmount(Math.max(1, amount));
            event.getDrops().add(core);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();

        if (!plugin.items().isMace(hand)) return;

        PlayerData data = plugin.getData(player);

        if (data.getTier() < 5) {
            if (hasCore(player)) {
                event.setCancelled(true);
                plugin.upgrade(player);
            }
            return;
        }

        if (data.getAbility() == Ability.DASH) {
            event.setCancelled(true);
            useDash(player);
        } else if (data.getAbility() == Ability.STUN) {
            event.setCancelled(true);
            armStun(player);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player target)) return;

        PlayerData data = plugin.getData(attacker);
        if (data.getTier() != 5 || data.getAbility() != Ability.STUN || !data.isStunArmed()) return;

        if (isOnCooldown(plugin.stunCooldowns(), attacker.getUniqueId(), plugin.cooldownSeconds("stun"))) {
            data.setStunArmed(false);
            return;
        }

        long duration = plugin.getConfig().getLong("stun.duration-ticks", 60L);
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) duration, 10, false, true, true));
        target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, (int) duration, 250, false, true, true));

        data.setStunArmed(false);
        plugin.stunCooldowns().put(attacker.getUniqueId(), System.currentTimeMillis());
        attacker.sendMessage(plugin.prefix() + ChatColor.AQUA + "Stun activated. Cooldown: 60s.");
    }

    private void useDash(Player player) {
        long seconds = plugin.cooldownSeconds("dash");
        Long last = plugin.dashCooldowns().get(player.getUniqueId());
        if (last != null) {
            long remaining = seconds - ((System.currentTimeMillis() - last) / 1000L);
            if (remaining > 0) {
                player.sendMessage(plugin.prefix() + ChatColor.RED + "Dash cooldown: " + remaining + "s");
                return;
            }
        }

        Vector direction = player.getLocation().getDirection().normalize();
        direction.multiply(1.8);
        direction.setY(Math.max(0.35, direction.getY() + 0.25));
        player.setVelocity(direction);

        plugin.dashCooldowns().put(player.getUniqueId(), System.currentTimeMillis());
        player.sendMessage(plugin.prefix() + ChatColor.GREEN + "Dash activated. Cooldown: 60s.");
    }

    private void armStun(Player player) {
        long seconds = plugin.cooldownSeconds("stun");
        Long last = plugin.stunCooldowns().get(player.getUniqueId());

        if (last != null) {
            long remaining = seconds - ((System.currentTimeMillis() - last) / 1000L);
            if (remaining > 0) {
                player.sendMessage(plugin.prefix() + ChatColor.RED + "Stun cooldown: " + remaining + "s");
                return;
            }
        }

        PlayerData data = plugin.getData(player);
        data.setStunArmed(true);
        player.sendMessage(plugin.prefix() + ChatColor.AQUA + "Stun armed. Your next hit will stun the target.");
    }

    private boolean isOnCooldown(Map<UUID, Long> map, UUID id, long seconds) {
        Long last = map.get(id);
        if (last == null) return false;
        return seconds - ((System.currentTimeMillis() - last) / 1000L) > 0;
    }

    private boolean hasCore(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (plugin.items().isCore(item)) return true;
        }
        return false;
    }
}
