package com.hcoremace.plugin;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class HCoreMacePlugin extends JavaPlugin {
    private DataManager dataManager;
    private ItemManager itemManager;
    private GuiManager guiManager;
    private final Map<UUID, PlayerData> players = new HashMap<>();
    private final Map<UUID, Long> dashCooldown = new HashMap<>();
    private final Map<UUID, Long> stunCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();

        dataManager = new DataManager(this);
        itemManager = new ItemManager(this);
        guiManager = new GuiManager(this);

        getServer().getPluginManager().registerEvents(new HCoreListener(this), this);
        getCommand("hcore").setExecutor(this::command);

        getLogger().info("H-Core Mace enabled.");
    }

    @Override
    public void onDisable() {
        for (Player player : getServer().getOnlinePlayers()) {
            PlayerData data = players.get(player.getUniqueId());
            if (data != null) dataManager.save(player, data);
        }
        getLogger().info("H-Core Mace disabled.");
    }

    public PlayerData getData(Player player) {
        return players.computeIfAbsent(player.getUniqueId(), id -> dataManager.load(player));
    }

    public boolean hasSavedData(Player player) {
        return getData(player).getPath() != Path.NONE;
    }

    public void firstJoin(Player player) {
        PlayerData data = getData(player);
        data.setPath(Path.NONE);
        data.setTier(1);
        data.setAbility(Ability.NONE);
        data.setStunArmed(false);

        player.getInventory().addItem(itemManager.createMace(Path.NONE, 1));
        dataManager.save(player, data);

        getServer().getScheduler().runTask(this, () -> guiManager.openPathMenu(player));
        player.sendMessage(prefix() + ChatColor.GREEN + "Choose your Mace path.");
    }

    public void choosePath(Player player, Path path) {
        PlayerData data = getData(player);
        if (data.getPath() != Path.NONE) {
            player.closeInventory();
            return;
        }

        data.setPath(path);
        data.setTier(1);

        replaceMace(player, path, 1);
        dataManager.save(player, data);

        player.closeInventory();
        player.sendMessage(prefix() + ChatColor.GREEN + "Path selected: " + ChatColor.WHITE + path.name());
    }

    public void chooseAbility(Player player, Ability ability) {
        PlayerData data = getData(player);
        if (data.getTier() < 5) {
            player.closeInventory();
            return;
        }

        data.setAbility(ability);
        data.setStunArmed(false);
        dataManager.save(player, data);

        player.closeInventory();
        player.sendMessage(prefix() + ChatColor.GREEN + "Ability selected: " + ChatColor.WHITE + ability.name());
    }

    public void upgrade(Player player) {
        PlayerData data = getData(player);
        if (data.getPath() == Path.NONE || data.getTier() >= 5) return;

        if (!removeOneCore(player)) {
            player.sendMessage(prefix() + ChatColor.RED + "You need an H-Core to upgrade.");
            return;
        }

        int newTier = data.getTier() + 1;
        data.setTier(newTier);
        replaceMace(player, data.getPath(), newTier);
        dataManager.save(player, data);

        player.sendMessage(prefix() + ChatColor.GREEN + "Mace upgraded to " + ChatColor.WHITE + "HC-" + newTier + ChatColor.GREEN + "!");

        if (newTier == 5) {
            getServer().getScheduler().runTask(this, () -> guiManager.openAbilityMenu(player));
        }
    }

    private boolean removeOneCore(Player player) {
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (!itemManager.isCore(item)) continue;

            if (item.getAmount() <= 1) {
                player.getInventory().setItem(slot, null);
            } else {
                item.setAmount(item.getAmount() - 1);
            }
            return true;
        }
        return false;
    }

    public void replaceMace(Player player, Path path, int tier) {
        ItemStack current = null;
        int currentSlot = -1;

        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (itemManager.isMace(item)) {
                current = item;
                currentSlot = slot;
                break;
            }
        }

        if (currentSlot >= 0) {
            player.getInventory().setItem(currentSlot, itemManager.createMace(path, tier));
        } else {
            player.getInventory().addItem(itemManager.createMace(path, tier));
        }
    }

    public void giveMace(Player player) {
        PlayerData data = getData(player);
        Path path = data.getPath() == Path.NONE ? Path.DENSITY : data.getPath();
        player.getInventory().addItem(itemManager.createMace(path, data.getTier()));
    }

    public void giveCore(Player player) {
        player.getInventory().addItem(itemManager.createCore());
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public ItemManager items() {
        return itemManager;
    }

    public GuiManager gui() {
        return guiManager;
    }

    public Map<UUID, Long> dashCooldowns() {
        return dashCooldown;
    }

    public Map<UUID, Long> stunCooldowns() {
        return stunCooldown;
    }

    public long cooldownSeconds(String key) {
        return getConfig().getLong("cooldowns." + key + "-seconds", 60L);
    }

    public String prefix() {
        return ChatColor.translateAlternateColorCodes('&',
                getConfig().getString("messages.prefix", "&8[&bH-Core&8] "));
    }

    private boolean command(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("hcore.admin")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.YELLOW + "/hcore give <player>");
            sender.sendMessage(ChatColor.YELLOW + "/hcore core <player>");
            sender.sendMessage(ChatColor.YELLOW + "/hcore reset <player>");
            return true;
        }

        Player target = getServer().getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player is not online.");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give" -> giveMace(target);
            case "core" -> giveCore(target);
            case "reset" -> {
                players.remove(target.getUniqueId());
                dataManager.reset(target);
                target.getInventory().remove(Material.MACE);
                target.sendMessage(prefix() + ChatColor.YELLOW + "Your H-Core data was reset.");
            }
            default -> sender.sendMessage(ChatColor.RED + "Unknown subcommand.");
        }
        return true;
    }
}
