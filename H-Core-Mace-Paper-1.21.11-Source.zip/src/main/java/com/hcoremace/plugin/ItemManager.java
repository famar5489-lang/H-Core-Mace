package com.hcoremace.plugin;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class ItemManager {
    private final NamespacedKey maceKey;
    private final NamespacedKey coreKey;

    public ItemManager(HCoreMacePlugin plugin) {
        maceKey = new NamespacedKey(plugin, "hcore_mace");
        coreKey = new NamespacedKey(plugin, "hcore");
    }

    public ItemStack createMace(Path path, int tier) {
        ItemStack item = new ItemStack(Material.MACE);
        applyMace(item, path, tier);
        return item;
    }

    public void applyMace(ItemStack item, Path path, int tier) {
        if (item == null || item.getType() != Material.MACE) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        meta.getPersistentDataContainer().set(maceKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(
                new NamespacedKey(maceKey.getNamespace(), "path"),
                PersistentDataType.STRING, path.name()
        );
        meta.getPersistentDataContainer().set(
                new NamespacedKey(maceKey.getNamespace(), "tier"),
                PersistentDataType.INTEGER, tier
        );

        String pathName = path == Path.DENSITY ? "Density" :
                path == Path.BREACH ? "Breach" : "Unchosen";

        meta.setDisplayName(ChatColor.AQUA + "H-Core Mace " + ChatColor.GRAY + "(HC-" + tier + ")");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Path: " + ChatColor.WHITE + pathName);
        lore.add(ChatColor.GRAY + "Tier: " + ChatColor.WHITE + tier + "/5");

        if (tier < 5) {
            lore.add("");
            lore.add(ChatColor.YELLOW + "Right-click while holding an H-Core");
            lore.add(ChatColor.YELLOW + "to upgrade this Mace.");
        } else {
            lore.add("");
            lore.add(ChatColor.GREEN + "MAX");
            lore.add(ChatColor.GRAY + "Ability: " + ChatColor.WHITE + "choose Dash or Stun");
        }

        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    public boolean isMace(ItemStack item) {
        if (item == null || item.getType() != Material.MACE || !item.hasItemMeta()) return false;
        Byte value = item.getItemMeta().getPersistentDataContainer().get(maceKey, PersistentDataType.BYTE);
        return value != null && value == (byte) 1;
    }

    public int getTier(ItemStack item) {
        if (!isMace(item)) return 0;
        Integer tier = item.getItemMeta().getPersistentDataContainer().get(
                new NamespacedKey(maceKey.getNamespace(), "tier"),
                PersistentDataType.INTEGER
        );
        return tier == null ? 0 : tier;
    }

    public Path getPath(ItemStack item) {
        if (!isMace(item)) return Path.NONE;
        String value = item.getItemMeta().getPersistentDataContainer().get(
                new NamespacedKey(maceKey.getNamespace(), "path"),
                PersistentDataType.STRING
        );
        try {
            return value == null ? Path.NONE : Path.valueOf(value);
        } catch (Exception ignored) {
            return Path.NONE;
        }
    }

    public ItemStack createCore() {
        ItemStack item = new ItemStack(Material.HEAVY_CORE);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.getPersistentDataContainer().set(coreKey, PersistentDataType.BYTE, (byte) 1);
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "H-Core");
        meta.setLore(List.of(
                ChatColor.GRAY + "Upgrade material for the H-Core Mace.",
                ChatColor.YELLOW + "Use it on your Mace to upgrade."
        ));
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCore(ItemStack item) {
        if (item == null || item.getType() != Material.HEAVY_CORE || !item.hasItemMeta()) return false;
        Byte value = item.getItemMeta().getPersistentDataContainer().get(coreKey, PersistentDataType.BYTE);
        return value != null && value == (byte) 1;
    }
}
