package com.hcoremace.plugin;

public final class PlayerData {
    private Path path = Path.NONE;
    private int tier = 1;
    private Ability ability = Ability.NONE;
    private boolean stunArmed = false;

    public Path getPath() {
        return path;
    }

    public void setPath(Path path) {
        this.path = path;
    }

    public int getTier() {
        return tier;
    }

    public void setTier(int tier) {
        this.tier = Math.max(1, Math.min(5, tier));
    }

    public Ability getAbility() {
        return ability;
    }

    public void setAbility(Ability ability) {
        this.ability = ability;
    }

    public boolean isStunArmed() {
        return stunArmed;
    }

    public void setStunArmed(boolean stunArmed) {
        this.stunArmed = stunArmed;
    }
}
