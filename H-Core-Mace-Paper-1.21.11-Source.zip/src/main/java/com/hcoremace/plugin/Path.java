package com.hcoremace.plugin;

public enum Path {
    NONE,
    DENSITY,
    BREACH
}
