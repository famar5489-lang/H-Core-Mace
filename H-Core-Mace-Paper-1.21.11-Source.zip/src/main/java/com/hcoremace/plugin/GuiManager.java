package com.hcoremace.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class GuiManager {
    private final HCoreMacePlugin plugin;

    public GuiManager(HCoreMacePlugin plugin) {
        this.plugin = plugin;
    }

    public void openPathMenu(Player player) {
        Inventory inv = Bukkit.createInventory(new PathHolder(), 27, ChatColor.DARK_AQUA + "Choose Your Path");

        inv.setItem(11, button(Material.DIAMOND, ChatColor.AQUA + "Density",
                ChatColor.GRAY + "Choose the Density path."));
        inv.setItem(15, button(Material.REDSTONE_BLOCK, ChatColor.RED + "Breach",
                ChatColor.GRAY + "Choose the Breach path."));

        player.openInventory(inv);
    }

    public void openAbilityMenu(Player player) {
        Inventory inv = Bukkit.createInventory(new AbilityHolder(), 27, ChatColor.DARK_AQUA + "Choose Your Ability");

        inv.setItem(11, button(Material.FEATHER, ChatColor.GREEN + "Dash",
                ChatColor.GRAY + "Right-click your MAX Mace.",
                ChatColor.GRAY + "Cooldown: 60 seconds."));
        inv.setItem(15, button(Material.POWDER_SNOW_BUCKET, ChatColor.AQUA + "Stun",
                ChatColor.GRAY + "Right-click to arm Stun.",
                ChatColor.GRAY + "Your next hit stuns the target.",
                ChatColor.GRAY + "Cooldown: 60 seconds."));

        player.openInventory(inv);
    }

    public void handleClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof PathHolder) && !(holder instanceof AbilityHolder)) return;

        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR || !clicked.hasItemMeta()) return;

        if (holder instanceof PathHolder) {
            String name = ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
            if ("Density".equalsIgnoreCase(name)) {
                plugin.choosePath(player, Path.DENSITY);
            } else if ("Breach".equalsIgnoreCase(name)) {
                plugin.choosePath(player, Path.BREACH);
            }
        } else if (holder instanceof AbilityHolder) {
            String name = ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
            if ("Dash".equalsIgnoreCase(name)) {
                plugin.chooseAbility(player, Ability.DASH);
            } else if ("Stun".equalsIgnoreCase(name)) {
                plugin.chooseAbility(player, Ability.STUN);
            }
        }
    }

    private ItemStack button(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(java.util.List.of(lore));
        item.setItemMeta(meta);
        return item;
    }

    public static final class PathHolder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
        public void setInventory(Inventory inventory) { this.inventory = inventory; }
    }

    public static final class AbilityHolder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
        public void setInventory(Inventory inventory) { this.inventory = inventory; }
    }
}
