package com.hcoremace.plugin;

public enum Ability {
    NONE,
    DASH,
    STUN
}
