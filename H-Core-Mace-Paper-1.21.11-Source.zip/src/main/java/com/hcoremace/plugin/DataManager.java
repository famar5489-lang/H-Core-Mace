package com.hcoremace.plugin;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public final class DataManager {
    private final HCoreMacePlugin plugin;
    private final File file;
    private final FileConfiguration data;

    public DataManager(HCoreMacePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException("Could not create players.yml", e);
            }
        }
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public PlayerData load(Player player) {
        UUID id = player.getUniqueId();
        String base = "players." + id;

        PlayerData pd = new PlayerData();
        pd.setPath(parsePath(data.getString(base + ".path", "NONE")));
        pd.setTier(data.getInt(base + ".tier", 1));
        pd.setAbility(parseAbility(data.getString(base + ".ability", "NONE")));
        pd.setStunArmed(false);
        return pd;
    }

    public void save(Player player, PlayerData pd) {
        UUID id = player.getUniqueId();
        String base = "players." + id;

        data.set(base + ".name", player.getName());
        data.set(base + ".path", pd.getPath().name());
        data.set(base + ".tier", pd.getTier());
        data.set(base + ".ability", pd.getAbility().name());
        data.set(base + ".stunArmed", false);

        saveFile();
    }

    public void reset(Player player) {
        data.set("players." + player.getUniqueId(), null);
        saveFile();
    }

    private void saveFile() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save players.yml: " + e.getMessage());
        }
    }

    private Path parsePath(String value) {
        try {
            return Path.valueOf(value.toUpperCase());
        } catch (Exception ignored) {
            return Path.NONE;
        }
    }

    private Ability parseAbility(String value) {
        try {
            return Ability.valueOf(value.toUpperCase());
        } catch (Exception ignored) {
            return Ability.NONE;
        }
    }
}
