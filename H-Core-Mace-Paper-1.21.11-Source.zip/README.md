# H-Core Mace — Paper 1.21.11

## Requirements
- Java 21
- Maven 3.9+
- Paper 1.21.11

## Build
Run:

mvn clean package

The plugin JAR will be created at:

target/H-Core-Mace-1.0.0.jar

Copy that JAR into your Paper server's `plugins` folder.

## Features
- First join gives the player an H-Core Mace.
- Density / Breach path selection.
- Starts at HC-1.
- PvP kill by a player using the H-Core Mace drops a custom H-Core.
- Right-clicking the Mace while an H-Core is in the inventory upgrades it.
- HC-5 is MAX.
- At HC-5 the player chooses Dash or Stun.
- Dash cooldown: 60 seconds.
- Stun cooldown: 60 seconds.
- Player data is saved in plugins/H-Core-Mace/players.yml.

## Admin
/hcore give <player>
/hcore core <player>
/hcore reset <player>

Permission:
hcore.admin
